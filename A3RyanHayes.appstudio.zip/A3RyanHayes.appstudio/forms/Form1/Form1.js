/*
Write a program to calculate debt-to-income ratio using a function. The function will do the calcuation using the numbers you provide it when you call it. DO NOT use any controls. Use alerts, prompts, console.log with template literals. For all user output - use console.log.  
Note: before you start, set the height property for this form
to 600. That will give you more space to work with (on a phone, it would simply scroll). 

Requirements
> Get these from the user (we will assume the user has only 3 debts):  
     - monthly car payment
     - monthly rent payment
     - monthly credit card payment
     - users' gross monthly income.
> create a function that takes four parameters (the 3 debts and the gross monthly income) and returns the debt-to-income ratio to the main program.
   Use this formula:
         (sum of the monthly debt payments/gross monthly income ) x 100
> display the answer from the main program, not from code that is in the function, on the console. 
*/


function debtIncome(carPmt,RentPmt,creditPmt,incomePmt) {
let debt = (carPmt + RentPmt + creditPmt)
let answer = (debt/incomePmt) x 100
return answer
}


let carPmt = Number(prompt("Enter your monthly car payment:")
let RentPmt = Number(prompt("Enter your monthly rent payment:")
let creditPmt = Number(prompt("Enter your monthly credit card payment:")
let incomePmt = Number(prompt("Enter your gross monthly income:")

console.log(debtIncome)