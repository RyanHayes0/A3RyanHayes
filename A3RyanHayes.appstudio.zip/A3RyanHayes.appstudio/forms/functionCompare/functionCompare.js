/*
Create a function named 'Compare' that takes two arguments (pass1, pass2) and is called from the main program.
Call the function from the main program and pass the two passwords to the function.
The function returns 'true' if the two passwords passed in were the same, or 'false' if they were  not the same.
Hint: .localeCompare() is a handy string method..... (see https://www.w3schools.com/jsref/jsref_localecompare.asp (Links to an external site.) )
The variables used inside the function must be declared in the function (the function parameters, etc). No global variables (ie. declared outside the function) may be used in the function.  
Back in the main program, when the function returns the answer, output this message to the console: 

The passwords are the same. 
OR
The passwords are not the same. 
*/


let password = prompt("Please enter a password")
let password1 = prompt("Please enter a password again")

function compare(password,password1) {
if (password==password1) {
return 'true'
} else {
 return 'false'
}
}