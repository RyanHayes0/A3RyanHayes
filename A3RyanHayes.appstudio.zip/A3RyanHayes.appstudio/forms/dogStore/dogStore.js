/*
The user must be able to see a list of all the products the store carries.
The user must be able to choose a product they want to add to their wish list. 
The program must be able to save item(s) to their wish list.  
Hint: an array?.....
The user must be able to see a list of all the products on their wish list. 
Program code must use array(s), events, event handler code, controls, control and form properties at a minimum. No prompts or alerts. 
Use global variables and function declarations when more than one event handler needs to use it. For example, the products array(s)
should be global (declare at the top of the form). 
These are the products and prices the store 'Dogs R Us' carries. Store these in a/an array(s). 
Hint: you can use one array or two that are synchronized. 

Crocheted Dog Toy, $10.00
Slow Feeder Bowl, $14.00
Pawz Grey Treat Jar, $20.00
Blue Sweet Dreams Thermal Pajamas, $30.00
Checker Chewy Vuiton Bowl, #32.00
Red Heart Sweater Dress, $27.00
Velvet Hair Bow - Sun Kissed, $12.00
Into the Wild Leash, $27.00

// save button, add watchlist button

let productsPrices = ["Crocheted Dog Toy","$10.00","Slow Feeder Bowl","$14.00","Pawz Grey Treat Jar","$20.00","Blue Sweet Dreams Thermal Pajamas","$30.00","Checker Chewy Vuiton Bowl","$32.00","Red Heart Sweater Dress","$27.00","Velvet Hair Bow-Sun Kissed","$12.00","Into the Wild Leash","$27.00"]
let wishList = [""]

lblProducts.onclick=function(){
  console.log(productPrices)
}

inptProducts.onclick=function(){
  
}

btnWatchlist.onclick=function(){
  inptProducts.value = wishList
}

btnAdd.onclick=function(){
  inptProducts.value = wishList
  
}

btnSave.onclick=function(){
  inptProducts.value = wishList
}
