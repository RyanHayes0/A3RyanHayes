/*
form named 'cityWhile'
uses 2 while loops
gets a city from user, then repeats until the user wants to stop entering cities
user can use any case mixture for input
keep the cities in array named 'cities'
when user is done entering cities, use a while loop to iterate through city array and output each city (one per line) to the console in all lower case using a template literal like this: 
omaha
st. louis
etc....
*/
let cities = [""]
let city = prompt("Enter the name of a city:") 
while (city != "stop") {
  prompt("Enter the name of a city:") 
  }
  console.log(cities,'\n')

let city = cities

  
while (city=="stop") {
 console.log(cities)
  }
prompt("Enter the name of a city:") 
